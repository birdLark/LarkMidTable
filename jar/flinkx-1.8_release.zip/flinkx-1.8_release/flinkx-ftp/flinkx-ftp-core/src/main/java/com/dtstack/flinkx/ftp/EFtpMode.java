package com.dtstack.flinkx.ftp;

/**
 * @author jiangbo
 * @date 2020/2/12
 */
public enum EFtpMode {

    /**
     * 被动方式
     */
    PASV,

    /**
     * 主动方式
     */
    PORT;
}
